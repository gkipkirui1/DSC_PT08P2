# ds-ab_testing

This repository describes the fundamentals of statistical A/B testing. It was created with love by the Flatiron School.
