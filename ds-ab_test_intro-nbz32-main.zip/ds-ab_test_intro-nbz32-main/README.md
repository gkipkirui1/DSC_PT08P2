# ds-ab_testing

This repository describes the fundamentals of statistical A/B testing and introduces statistical power and effect size. It was created with love by the Flatiron School.
