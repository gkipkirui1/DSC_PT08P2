# ds-simple_linear_regression

This repository describes the algorithm of simple linear regression. It was created with love by the Flatiron School.
